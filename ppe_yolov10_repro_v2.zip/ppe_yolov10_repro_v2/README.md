# PPE Detection — Reproducibility Package
Run `python src/fit_saturation_model.py --results_dir data/results_raw --out_dir outputs --assume_counts "SHEL5K:images=5000,classes=4" --assume_counts "CHV:images=1330,classes=6" --assume_counts "SH17:images=8099,classes=17"`
